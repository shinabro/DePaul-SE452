$(document).ready(function(){
  $('#no-script').remove();
});